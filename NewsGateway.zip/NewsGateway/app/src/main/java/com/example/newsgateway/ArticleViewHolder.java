package com.example.newsgateway;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

public class ArticleViewHolder extends RecyclerView.ViewHolder {

    TextView title;
    TextView date;
    TextView author;
    ImageView img;
    TextView text;
    TextView ctr;
    ConstraintLayout bigCl;

    public ArticleViewHolder(@NonNull View itemView){
        super(itemView);

        title = itemView.findViewById(R.id.headline_tv);
        date = itemView.findViewById(R.id.date_tv);
        author = itemView.findViewById(R.id.author_tv);
        img = (ImageView) itemView.findViewById(R.id.pic_iv);
        text = itemView.findViewById(R.id.text_tv);
        ctr = itemView.findViewById(R.id.pg_num_tv);
        bigCl = (ConstraintLayout) itemView.findViewById(R.id.cl);


    }
}
