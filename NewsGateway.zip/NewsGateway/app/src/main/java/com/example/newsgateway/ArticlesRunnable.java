package com.example.newsgateway;

import android.graphics.drawable.Drawable;
import android.graphics.drawable.PictureDrawable;
import android.net.Uri;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;
import com.caverock.androidsvg.SVG;
import java.util.Collections;



public class ArticlesRunnable implements Runnable{

    private static final String TAG = "MyRunnable";
    private final MainActivity mainActivity;
    private String id;

    private static final String weatherURL = "https://newsapi.org/v2/top-headlines?";
    private static final String yourAPIKey = "be0b9b9fdc9d4489a3c272397895201b";

    ArticlesRunnable(MainActivity mainActivity, String id) {
        Log.d(TAG, "ArticlesRunnable: IN ");
        this.mainActivity = mainActivity;
        this.id = id;
    }

    public void run() {
        Log.d(TAG, "AR run: Starting Run");

        Uri.Builder buildURL = Uri.parse(weatherURL).buildUpon();
        buildURL.appendQueryParameter("sources", id);
        buildURL.appendQueryParameter("apiKey", yourAPIKey);

        String urlToUse = buildURL.build().toString();
        Log.d(TAG, "AR doInBackground: URL: " + urlToUse);

        StringBuilder sb = new StringBuilder();

        try {
            URL url = new URL(urlToUse);

            Log.d(TAG, "AR run: 1");
            HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
            Log.d(TAG, "AR run: 2");
            connection.setRequestMethod("GET");
            Log.d(TAG, "AR run: 3");
            connection.addRequestProperty("User-Agent","");
            Log.d(TAG, "AR run: 4");
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            Log.d(TAG, "AR run: 5");
            connection.setRequestProperty("Accept", "application/json");
            Log.d(TAG, "AR run: 6");
            connection.connect();
            Log.d(TAG, "AR run: 7");

            if (connection.getResponseCode() != HttpsURLConnection.HTTP_OK) {
                Log.d(TAG, "AR run: NOT HTTP_OK");
                InputStream is = connection.getErrorStream();
                BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append('\n');
                }
                handleError(sb.toString());
                return;
            }

            Log.d(TAG, "AR run: HTTP_OK->Input Stream");
            InputStream is = connection.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));
            Log.d(TAG, "AR run: AFter reader dec, b4 while loop");

            String line;
            int i = 0;
            while ((line = reader.readLine()) != null) {
                Log.d(TAG, "AR run: " + i + ":   " + line);
                i+=1;
                sb.append(line).append('\n');
            }

            Log.d(TAG, "AR doInBackground: sb.toString(): " + sb.toString());

        } catch (Exception e) {
            Log.e(TAG, "AR doInBackground: e: ", e);
            handleResults(null);
            return;
        }
        handleResults(sb.toString());

    }

    public void handleError(String s) {
        Log.d(TAG, "AR handleError: IN HERE");
        String msg = "Error: ";
        try {
            JSONObject jObjMain = new JSONObject(s);
            msg += jObjMain.getString("message");

        } catch (JSONException e) {
            msg += e.getMessage();
        }

        String finalMsg = String.format("%s ", msg);
        Log.d(TAG, "AR handleError: " + finalMsg);

    }

    public void handleResults(final String jsonString) {
        Log.d(TAG, "AR handleResults: " + jsonString);

        ArrayList<Article> a = parseJSON(jsonString);
        if (a == null) {
            mainActivity.runOnUiThread(mainActivity::downloadFailed);
            return;
        }
        mainActivity.runOnUiThread(() -> mainActivity.receiveArticles(a)); // TODO: Create receiveArticles in MA
    }

    private ArrayList<Article> parseJSON(String s){
        Log.d(TAG, "AR parseJSON: In parseJSON");

        try{
            JSONObject sobj = new JSONObject(s);
            JSONArray jArs = sobj.getJSONArray("articles");  //Gets the array of all articles
            ArrayList ars = new ArrayList<Article>();

            for (int i = 0; i < jArs.length(); i++){
                JSONObject tmpjo = jArs.getJSONObject(i);
                Article tmpa = new Article(tmpjo.getString("author"), tmpjo.getString("title"), tmpjo.getString("description"), tmpjo.getString("url"), tmpjo.getString("urlToImage"), tmpjo.getString("publishedAt"));
                /*
                Drawable drawable = null;
                try {
                    Log.d(TAG, "parseJSON: svg: " + tmpjo.getString("urlToImage"));
                    InputStream input = new java.net.URL(tmpjo.getString("urlToImage")).openStream();
                    SVG svg = SVG.getFromInputStream(input);
                    drawable = new PictureDrawable(svg.renderToPicture());
                    Toast.makeText(mainActivity.getApplicationContext(), "Pic Download succeeded", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(mainActivity.getApplicationContext(), "Pic Download Failed", Toast.LENGTH_SHORT).show();
                }
                 */
                ars.add(tmpa);
            }

            return ars;
        }catch (Exception e) {
            Log.d(TAG, "parseJSON: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

}



