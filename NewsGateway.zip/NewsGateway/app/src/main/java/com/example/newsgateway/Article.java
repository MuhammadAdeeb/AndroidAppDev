package com.example.newsgateway;

import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Locale;

public class Article implements Serializable {
    private String author;
    private String title;
    private String description;
    private String url;
    private String urlToImage;
    private String publishedAt;
    private String dt;


    @RequiresApi(api = Build.VERSION_CODES.O)
    Article(String a, String t, String d, String u, String ui, String p) throws ParseException {
        author = a;
        title = t;
        description = d;
        url = u;
        urlToImage = ui;
        publishedAt =p;

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm");
        ZonedDateTime zdt = ZonedDateTime.parse(p).truncatedTo(ChronoUnit.SECONDS).withZoneSameInstant(ZoneId.of("America/Chicago"));
        this.dt = zdt.format(dtf);


        // SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        // SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");
        // Date date = inputFormat.parse(p);
        // String formattedDate = outputFormat.format(date);
        // this.dt = formattedDate;

        // DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        // String dateString = p.replace("Z", "GMT+00:00");
        // Date date = dateFormat.parse(dateString);
        // this.dt = date;

        //SimpleDateFormat jdate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.forLanguageTag(publishedAt));
        // DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        // Date dt = (Date) df.parse(publishedAt);
        // DateFormat ff = new SimpleDateFormat("MMMM-dd-yyyy HH:mm");
        // this.dt = ff.format(dt);
        // this.dt = dt;
        // SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        // Date dt = sdf.parse()
    }


    public String getDt() {
        return dt;
    }

    public String getAuthor() {
        return author;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getUrl() {
        return url;
    }

    public String getUrlToImage() {
        return urlToImage;
    }

    public String getPublishedAt() {
        return publishedAt;
    }
}
