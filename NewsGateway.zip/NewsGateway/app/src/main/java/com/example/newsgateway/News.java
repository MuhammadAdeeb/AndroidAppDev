package com.example.newsgateway;

import java.io.Serializable;
import android.graphics.drawable.Drawable;

import androidx.annotation.NonNull;


public class News implements Comparable<News>, Serializable {

    private String id;
    private String name;
    private String category;
    private String lang;
    private String country;
    private String lc;
    private String cc;
    private int c;

    News(String id, String name, String category, String lang, String country, String lc, String cc){
        this.id = id;
        this.name = name;
        this.category = category;
        this.lang = lang;
        this.country = country;
        this.lc = lc;
        this.cc = cc;
    }
    public void setColor(int c){
        this.c = c;
    }

    public String getCategory() {
        return category;
    }

    public String getCountry() {
        return country;
    }

    public String getLang() {
        return lang;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getLc() {return lc;}

    public String getCc() {return cc;}

    @Override
    public int compareTo(News news)  {
        return name.compareTo(news.name);
    }
}
