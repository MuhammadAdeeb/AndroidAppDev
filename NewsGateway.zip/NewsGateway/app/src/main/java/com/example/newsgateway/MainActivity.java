package com.example.newsgateway;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Objects;

// xmlns:android="http://schemas.android.com/apk/res/android"
public class MainActivity extends AppCompatActivity {

    // API Key:
    // be0b9b9fdc9d4489a3c272397895201b
    private static final String TAG = "MainActivity";
    // TODO:
    private final HashMap<String, ArrayList<News>> categToNews = new HashMap<>();
    private final HashMap<String, ArrayList<News>> langToNews = new HashMap<>();
    private final HashMap<String, ArrayList<News>> countryToNews = new HashMap<>();

    private String tclicked = null;
    private String cclicked = null;
    private String lclicked = null;
    private String aclicked = null;

    private ArrayList<String> ttempList;
    private ArrayList<String> ctempList;
    private ArrayList<String> ltempList;

    private ArrayList<News> tmp_lst_news = new ArrayList<>();
    private ArrayList<String> tmp_lst_names = new ArrayList<>();
    // ArrayList<String> tmp_lst_names

    private ArrayList<String> all_sources = new ArrayList<>();
    private ArrayList<News> all_sources_news = new ArrayList<>();

    private DrawerLayout mDrawerLayout;
    private ListView mDrawerList;
    private ActionBarDrawerToggle mDrawerToggle;

    private Menu optMenu;

    private ArticleAdapter artAdap;
    private ArrayList<Article> aList = new ArrayList<>();

    private ViewPager2 viewPager2;

    private SharedPreferences pref;
    private SharedPreferences.Editor prefsEditor;

    private int parentSubmenu = -100;
    private int menuItem = -100;
    public static int article_position = 0;

    private ArrayList<Article> n_save = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (doNetCheck() == false){
            Log.d(TAG, "onCreate: Network check is false");
            TextView tv = findViewById(R.id.noNet);
            // tv.setText("No Internet Connection");
            Toast.makeText(this, "NO INTERNET CONNECTION!", Toast.LENGTH_LONG).show();

            findViewById(R.id.progressBar).setVisibility(View.INVISIBLE);
        }else{
            mDrawerLayout = findViewById(R.id.drawer_layout);
            mDrawerList = findViewById(R.id.left_drawer);

            viewPager2 = findViewById(R.id.view_pager);

            artAdap = new ArticleAdapter(this, aList);
            viewPager2.setAdapter(artAdap);
            viewPager2.setOrientation(ViewPager2.ORIENTATION_HORIZONTAL);
            Log.d(TAG, "onCreate: NetCheck is True, now calling download");
            mDrawerList.setOnItemClickListener(
                    (parent, view, position, id) -> selectItem(position)
            );

            mDrawerToggle = new ActionBarDrawerToggle(
                    this,
                    mDrawerLayout,
                    R.string.drawer_open,
                    R.string.drawer_close
            );
            mDrawerToggle.syncState();

            pref = getSharedPreferences("PREF", Context.MODE_PRIVATE);
            prefsEditor = pref.edit();

            /*
            if (pref.contains("t_click"))
                tclicked = pref.getString("t_click", "");
            if (pref.contains("c_click"))
                cclicked = pref.getString("c_click", "");
            if (pref.contains("l_click"))
                lclicked = pref.getString("l_click", "");

            if (pref.contains("a_click"))
                aclicked = pref.getString("a_click", null);
            if (pref.contains("psm"))
                parentSubmenu = pref.getInt("psm", 0);
            if (pref.contains("mi"))
                menuItem = pref.getInt("mi", 0);

             */
            /*
                lat = new Double(pref.getString("lat", "41.8675766"));
                lng = new Double(pref.getString("lng", "-87.616232"));
                fahrenheit = pref.getBoolean("fahrenheit", true); //default to true; can assign it using the saved setting!
                cty_st = pref.getString("cty_st", "Chicago, IL");
             */
            download();
        }
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        if (doNetCheck() == true) {
            mDrawerToggle.syncState();
        }
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Pass any configuration change to the drawer toggls
        if (doNetCheck() == true) {
            mDrawerToggle.onConfigurationChanged(newConfig);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        optMenu = menu;
        return true;
        // return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (mDrawerToggle.onOptionsItemSelected(item)) { //Clicked the Toggle
            return true;
        }

        Log.d(TAG, "onOptionsItemSelected: Selected: " + item.getTitle());

        if (item.hasSubMenu()) { // Go to Categories Submenu
            return true;
        }

        int parentSubmenu_og = item.getGroupId();
        int menuItem_og = item.getItemId();

        parentSubmenu = item.getGroupId();
        menuItem = item.getItemId();

        Log.d(TAG, "onOptionsItemSelected: ParentSM -> MenuItem: " + parentSubmenu + "  " + menuItem);

        // tmp_lst_news = new ArrayList<>();
        // Empty the ArrayList
        // ArrayList<String> tmp_lst_names = new ArrayList<>();
        String t;

        sort_arts();

        if (tmp_lst_names.size() == 0){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            // builder.setIcon(R.drawable.icon1);
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });

            builder.setMessage("Please try a different search");
            builder.setTitle("No Sources Found");

            AlertDialog dialog = builder.create();
            dialog.show();
        }

        return super.onOptionsItemSelected(item);
    }

    private void sort_arts(){
        String t;
        tmp_lst_news.clear();
        tmp_lst_names.clear();

        if (parentSubmenu == 0){
            if (menuItem == -1){
                tclicked = "all";
                Log.d(TAG, "sort_arts: all_sources_news: "  + all_sources_news);
                tmp_lst_news = (ArrayList<News>) all_sources_news.clone();
            }else {
                t = ttempList.get(menuItem);
                tclicked = t;
                tmp_lst_news = (ArrayList<News>) categToNews.get(t).clone();
                Log.d(TAG, "onOptionsItemSelected: IN Topics: " + tmp_lst_news);
            }
            if (cclicked != null && cclicked != "all"){
                ArrayList<News> tmp = new ArrayList<>(countryToNews.get(cclicked));
                tmp_lst_news.retainAll(tmp);
            }
            if (lclicked != null && lclicked != "all"){
                ArrayList<News> tmp = new ArrayList<>(langToNews.get(lclicked));
                tmp_lst_news.retainAll(tmp);
            }

        } else if (parentSubmenu == 1){
            if (menuItem == -1){
                cclicked = "all";
                Log.d(TAG, "sort_arts: all_sources_news: "  + all_sources_news);
                tmp_lst_news = (ArrayList<News>) all_sources_news.clone();
            }else {
                t = ctempList.get(menuItem);
                cclicked = t;
                tmp_lst_news = (ArrayList<News>) countryToNews.get(t).clone();
                Log.d(TAG, "!!!sort_arts: countrytonews: " + countryToNews);
                Log.d(TAG, "onOptionsItemSelected: In Country: " + tmp_lst_news);
            }
            if (tclicked != null && tclicked != "all"){
                ArrayList<News> tmp = new ArrayList<>(categToNews.get(tclicked));
                tmp_lst_news.retainAll(tmp);
            }
            if (lclicked != null && lclicked != "all"){
                ArrayList<News> tmp = new ArrayList<>(langToNews.get(lclicked));
                tmp_lst_news.retainAll(tmp);
            }
        } else if (parentSubmenu == 2){
            if (menuItem == -1){
                lclicked = "all";
                Log.d(TAG, "sort_arts: all_sources_news: "  + all_sources_news);
                tmp_lst_news = (ArrayList<News>) all_sources_news.clone();
            }else {
                t = ltempList.get(menuItem);
                lclicked = t;
                tmp_lst_news = (ArrayList<News>) langToNews.get(t).clone();
                Log.d(TAG, "onOptionsItemSelected: In Langs: " + tmp_lst_news);
            }
            if (tclicked != null && tclicked != "all"){
                ArrayList<News> tmp = new ArrayList<>(categToNews.get(tclicked));
                tmp_lst_news.retainAll(tmp);
            }
            if (cclicked != null && cclicked != "all"){
                ArrayList<News> tmp = new ArrayList<>(countryToNews.get(cclicked));
                tmp_lst_news.retainAll(tmp);
            }
        }
        /*
        prefsEditor.putString("t_click", tclicked);
        prefsEditor.putString("c_click", cclicked);
        prefsEditor.putString("l_click", lclicked);

        prefsEditor.putInt("psm", parentSubmenu);
        prefsEditor.putInt("mi", menuItem);
        prefsEditor.apply();
         */

        for (News n: tmp_lst_news){
            tmp_lst_names.add(n.getName());
        }

        Log.d(TAG, "onOptionsItemSelected: Before Drawer Updated");
        mDrawerList.setAdapter(new ArrayAdapter<>(this,
                R.layout.drawer_item, tmp_lst_names));

        setTitle("NewsGateway(" + tmp_lst_news.size() + ")");
    }

    private boolean doNetCheck() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        if (cm == null) {
            Toast.makeText(this, "Cannot access ConnectivityManager", Toast.LENGTH_SHORT).show();
            return false;  // No connection
        }

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (activeNetwork == null)
            return false; // No connection

        // Check for active live connection
        boolean isConnected = activeNetwork.isConnectedOrConnecting();

        // Check if the connection is metered (possibly paid data)
        boolean isMetered = cm.isActiveNetworkMetered();
        return isConnected;
    }

    public void download(){
        /*if (running){ //makes sure no new thread is ran if user clicks on weather update request again
            Toast.makeText(this, "Wait for Task to complete", Toast.LENGTH_SHORT).show();
            return;
        }
        running = true;*/
        Log.d(TAG, "download: b4 starting new thread");
        //TODO:
        MyRunnable myRunnable = new MyRunnable(this);
        new Thread(myRunnable).start();

        Log.d(TAG, "download: Started the thread");
    }

    public void receiveData(ArrayList<News> newsList) { //Weather weather: correct parameter
        Log.d(TAG, "receiveData: RECEIVED DATA");

        // all_sources = new ArrayList<>();
        //TODO:
        for(News n: newsList){
            String ctg = n.getCategory();
            String cty = n.getCountry();
            String lng = n.getLang();
            Log.d(TAG, "receiveData: ctd, cty, lng: " + ctg + "  " + cty + "  " + lng);
            String nm = n.getName();
            Log.d(TAG, "receiveData: NAME: " + nm);

            tmp_lst_news.add(n);
            all_sources_news.add(n);
            all_sources.add(nm);

            if (!categToNews.containsKey(ctg))
                categToNews.put(ctg, new ArrayList<>());
            Objects.requireNonNull(categToNews.get(ctg)).add(n);

            if (!countryToNews.containsKey(cty))
                countryToNews.put(cty, new ArrayList<>());
            Objects.requireNonNull(countryToNews.get(cty)).add(n);

            if (!langToNews.containsKey(lng))
                langToNews.put(lng, new ArrayList<>());
            Objects.requireNonNull(langToNews.get(lng)).add(n);
        }

        SubMenu t_sm = optMenu.addSubMenu("Topics");
        SubMenu c_sm = optMenu.addSubMenu("Countries");
        SubMenu l_sm = optMenu.addSubMenu("Languages");

        Log.d(TAG, "receiveData: Before Casting ");
        ttempList = new ArrayList<>(categToNews.keySet());
        ctempList = new ArrayList<>(countryToNews.keySet());
        ltempList = new ArrayList<>(langToNews.keySet());
        Log.d(TAG, "receiveData: AFter Casting ");

        Collections.sort(ttempList);
        Collections.sort(ctempList);
        Collections.sort(ltempList);
        Collections.sort(all_sources);
        Collections.sort(all_sources_news);
        Collections.sort(tmp_lst_news);
        //tmp_lst_news = all_sources;
        Log.d(TAG, "receiveData: all_sources: " + all_sources);

        t_sm.add(0, -1, 0, "All");
        c_sm.add(1, -1, 0, "All");
        l_sm.add(2, -1, 0, "All");

        int t = 0;
        for (String s : ttempList) {
            t_sm.add(0, t, 0, s);
            t += 1;
        }

        int u = 0;
        for (String s : ctempList) {
            c_sm.add(1, u, 0, s);
            u+=1;
        }

        int v = 0;
        for (String s : ltempList) {
            l_sm.add(2,v,0,s);
            v+=1;
        }

        // ArrayList<String> tmpal = new ArrayList<>(categToNews.keySet());
        for(News nw: newsList){
            for(int i = 0; i < ttempList.size(); i++){
                if(nw.getCategory() == ttempList.get(i))
                    nw.setColor(i);
            }
        }

        mDrawerList.setAdapter(new ArrayAdapter<>(this,
                R.layout.drawer_item, all_sources));

        setTitle("NewsGateway(" + tmp_lst_news.size() + ")");

        if (menuItem != -100) {
            sort_arts();
        }
        /*
        if (aclicked != null) {
            Log.d(TAG, "receiveData: aClicked isn't null");
            selectItem(Integer.parseInt(aclicked));
        }*/

        findViewById(R.id.progressBar).setVisibility(View.GONE);
    }

    public void receiveArticles(ArrayList<Article> aList) { //Weather weather: correct parameter
        Log.d(TAG, "receiveArticles: In receiveArticles, size: " + aList.size());
        Log.d(TAG, "receiveArticles: "+ aList.get(0).getDescription());
        /*
        Log.d(TAG, "receiveArticles: "+ aList.get(1).getTitle());
        Log.d(TAG, "receiveArticles: "+ aList.get(2).getTitle());
        Log.d(TAG, "receiveArticles: "+ aList.get(3).getTitle());
        Log.d(TAG, "receiveArticles: "+ aList.get(4).getTitle());
        Log.d(TAG, "receiveArticles: "+ aList.get(5).getTitle());
        Log.d(TAG, "receiveArticles: "+ aList.get(6).getTitle());
        Log.d(TAG, "receiveArticles: "+ aList.get(7).getTitle());
        Log.d(TAG, "receiveArticles: "+ aList.get(8).getTitle());
        Log.d(TAG, "receiveArticles: "+ aList.get(9).getTitle());
         */
        //Toast.makeText(this, "size: " + aList.size(), Toast.LENGTH_SHORT).show();

        if (aList == null) {
            Toast.makeText(this, "Data loader failed", Toast.LENGTH_LONG).show();
        } else {
            n_save = aList;
            Log.d(TAG, "receiveArticles: this.aList b4: " + this.aList);
            this.aList.clear();
            this.aList.addAll(aList);
            Log.d(TAG, "receiveArticles: this.aList After: " + this.aList);
            // YourView.setBackgroundColor(Color.argb(255, 255, 255, 255));

            ConstraintLayout cl = (ConstraintLayout) findViewById(R.id.frame);
            cl.setBackgroundColor(Color.WHITE);
            artAdap.notifyItemRangeChanged(0, aList.size());
        }
    }

    private void selectItem(int position) {
        Log.d(TAG, "selectItem: You chose item # " + position);

        if (doNetCheck() == false){
            Log.d(TAG, "selectItem: Network check is false");
            Toast.makeText(this, "NO INTERNET CONNECTION!", Toast.LENGTH_LONG).show();
            mDrawerLayout.closeDrawer(mDrawerList);
        }else {
            if (tmp_lst_news.size() >= position) {
                String s = tmp_lst_news.get(position).getId();

                ArticlesRunnable ar = new ArticlesRunnable(this, s);
                new Thread(ar).start();

                mDrawerLayout.closeDrawer(mDrawerList);
                setTitle(tmp_lst_news.get(position).getName());
                viewPager2.setCurrentItem(0);

                aclicked = Integer.toString(position);

            }
        }
    }

    public void downloadFailed() {
        Log.d(TAG, "downloadFailed: ");
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {

        if (tclicked != null)
            outState.putString("t_click", tclicked);
        if (cclicked != null)
            outState.putString("c_click", cclicked);
        if (lclicked != null)
            outState.putString("l_click", lclicked);
        if (aclicked != null) {
            outState.putString("a_click", aclicked);
            outState.putSerializable("news_click", n_save);
        }
        if (parentSubmenu != -100)
            outState.putInt("psm", parentSubmenu);
        if (menuItem != -100)
            outState.putInt("mi", menuItem);


        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        if (savedInstanceState.containsKey("t_click"))
            tclicked = savedInstanceState.getString("t_click");
        if (savedInstanceState.containsKey("c_click"))
            cclicked = savedInstanceState.getString("c_click");
        if (savedInstanceState.containsKey("l_click"))
            lclicked = savedInstanceState.getString("l_click");
        if (savedInstanceState.containsKey("a_click")) {
            aclicked = savedInstanceState.getString("a_click");
            n_save = (ArrayList<Article>) savedInstanceState.getSerializable("news_click");
            loadArticle(n_save);
        }
        if (savedInstanceState.containsKey("psm"))
            parentSubmenu = savedInstanceState.getInt("psm");
        if (savedInstanceState.containsKey("mi"))
            menuItem = savedInstanceState.getInt("mi");

    }

    private void loadArticle(ArrayList<Article> nc){
        this.aList.clear();
        this.aList.addAll(nc);
        Log.d(TAG, "receiveArticles: this.aList After: " + this.aList);
        // YourView.setBackgroundColor(Color.argb(255, 255, 255, 255));

        ConstraintLayout cl = (ConstraintLayout) findViewById(R.id.frame);
        cl.setBackgroundColor(Color.WHITE);
        artAdap.notifyItemRangeChanged(0, aList.size());
        viewPager2.setCurrentItem(article_position - 1);
        // artAdap.set

    }

}