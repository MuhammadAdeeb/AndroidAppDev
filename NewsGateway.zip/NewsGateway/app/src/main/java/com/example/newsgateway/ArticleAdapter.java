package com.example.newsgateway;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import android.content.pm.PackageManager;
import android.net.Uri;
import androidx.appcompat.app.AlertDialog;
import com.squareup.picasso.Picasso;


public class ArticleAdapter extends RecyclerView.Adapter<ArticleViewHolder> {

    private static final String TAG = "ArticleAdapter";
    private MainActivity ma;
    private ArrayList<Article> aList;
    private int art_num;

    public ArticleAdapter(MainActivity ma, ArrayList<Article> aList){
        this.ma = ma;
        this.aList = aList;
    }

    @NonNull
    @Override
    public ArticleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ArticleViewHolder(
                LayoutInflater.from(parent.getContext()).
                        inflate(R.layout.articles, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ArticleViewHolder holder, @SuppressLint("RecyclerView") int position) {

        Picasso picasso = Picasso.get();
        Article ar = aList.get(position);
        // art_num = position;
        ma.article_position = position;

        // TODO: For Pic:
        // final int resourceId = ma.getResources().getIdentifier(ar.getName(), "drawable", ma.getPackageName());
        // TODO: Put in the ImgView
        // holder.img.setImageResource();


        if (ar.getTitle() == "null")
            holder.title.setVisibility(RecyclerView.GONE);
        else
            holder.title.setText(ar.getTitle());

        if (ar.getPublishedAt() == "null")
            holder.date.setVisibility(RecyclerView.GONE);
        else {
            /*

            String jdate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.getDefault()).format(new Date(dt * 1000));
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date d = null;
            try {
                d = sdf.parse(ar.getPublishedAt());
            } catch (ParseException e) {
                e.printStackTrace();
            }
             */
            holder.date.setText(ar.getDt());

        }

        if (ar.getAuthor() == "null")
            holder.author.setVisibility(RecyclerView.GONE);
        else
            holder.author.setText(ar.getAuthor());

        if (ar.getDescription() == "null")
            holder.text.setVisibility(RecyclerView.GONE);
        else
            holder.text.setText(ar.getDescription());

        if (ar.getUrlToImage() == "null"){
            int icon_id = ma.getResources().getIdentifier("noimage", "drawable", ma.getPackageName());
            //holder.img.setImageDrawable(R.drawable.noimage);
            holder.img.setImageResource(icon_id);
            Log.d(TAG, "ArtAdap: onBindViewHolder: No Image for this article!");
        }else {
            // if (error):
            int icon_id = ma.getResources().getIdentifier("brokenimage", "drawable", ma.getPackageName());
            picasso.load(ar.getUrlToImage())
                    .error(R.drawable.brokenimage)
                    .placeholder(R.drawable.loading)
                    .into(holder.img);

        }

        holder.ctr.setText((position + 1) + " of " + aList.size());

        Log.d(TAG, "ArAdap: onBindViewHolder: right b4 cl listener");
        holder.title.setOnClickListener(v->clicked(ar.getUrl()));
        holder.text.setOnClickListener(v->clicked(ar.getUrl()));
        holder.img.setOnClickListener(v->clicked(ar.getUrl()));

    }

    @Override
    public int getItemCount() {
        return aList.size();
    }

    public void clicked(String id){
        Log.d(TAG, "ArAdap: clicked: " + id);

        String url = id;

        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

        if (intent.resolveActivity(ma.getPackageManager()) != null) {
            ma.startActivity(intent);
        } else {
            // makeErrorAlert("No Application found that handles ACTION_VIEW (twitter/https) intents");
            Toast.makeText(ma.getApplicationContext(), "No Application to handle request", Toast.LENGTH_SHORT).show();
        }
        // Toast.makeText(ma.getApplicationContext(), id, Toast.LENGTH_LONG).show();
    }

    public static Drawable LoadImageFromWebOperations(String url) {
        try {
            InputStream is = (InputStream) new URL(url).getContent();
            Drawable d = Drawable.createFromStream(is, "online");
            return d;
        } catch (Exception e) {
            return null;
        }
    }
}
