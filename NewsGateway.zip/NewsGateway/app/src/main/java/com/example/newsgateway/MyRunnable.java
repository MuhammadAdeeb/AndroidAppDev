package com.example.newsgateway;

import android.graphics.drawable.Drawable;
import android.graphics.drawable.PictureDrawable;
import android.net.Uri;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

import javax.net.ssl.HttpsURLConnection;

public class MyRunnable implements Runnable{

    private static final String TAG = "MyRunnable";
    private final MainActivity mainActivity;
    private String symbol;

    private static final String weatherURL = "https://newsapi.org/v2/sources?";
    // weatherURL = "https://api.openweathermap.org/data/2.5/onecall?";
    // https://api.openweathermap.org/data/2.5/onecall?lat=#########&lon=#########
    // &appid=your_api_key&units=units_selection&lang=en&exclude=minutely
    // https://newsapi.org/v2/top-headlines?sources=cnn&apiKey= ABC123xyz

    private static final String yourAPIKey = "be0b9b9fdc9d4489a3c272397895201b";
            
    MyRunnable(MainActivity mainActivity) {
        Log.d(TAG, "MyRunnable: IN ");
        this.mainActivity = mainActivity;
    }

    public void run() {
        Log.d(TAG, "run: Starting Run");

        Uri.Builder buildURL = Uri.parse(weatherURL).buildUpon();
        buildURL.appendQueryParameter("apiKey", yourAPIKey);

        String urlToUse = buildURL.build().toString();
        Log.d(TAG, "doInBackground: URL: " + urlToUse);

        StringBuilder sb = new StringBuilder();

        try {
            URL url = new URL(urlToUse);

            Log.d(TAG, "run: 1");
            HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
            Log.d(TAG, "run: 2");
            connection.setRequestMethod("GET");
            Log.d(TAG, "run: 3");
            connection.addRequestProperty("User-Agent","");
            Log.d(TAG, "run: 4");
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            Log.d(TAG, "run: 5");
            connection.setRequestProperty("Accept", "application/json");
            Log.d(TAG, "run: 6");
            connection.connect();
            Log.d(TAG, "run: 7");
            if (connection.getResponseCode() != HttpsURLConnection.HTTP_OK) {
                Log.d(TAG, "run: NOT HTTP_OK");
                InputStream is = connection.getErrorStream();
                BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append('\n');
                }
                handleError(sb.toString());
                return;
            }

            Log.d(TAG, "run: HTTP_OK->Input Stream");
            InputStream is = connection.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));
            Log.d(TAG, "run: AFter reader dec, b4 while loop");

            String line;
            int i = 0;
            while ((line = reader.readLine()) != null) {
                Log.d(TAG, "run: " + i + ":   " + line);
                i+=1;
                sb.append(line).append('\n');
            }

            Log.d(TAG, "doInBackground: sb.toString(): " + sb.toString());

        } catch (Exception e) {
            Log.e(TAG, "doInBackground: e: ", e);
            handleResults(null);
            return;
        }
        handleResults(sb.toString());

    }

    public void handleError(String s) {
        Log.d(TAG, "handleError: IN HERE");
        String msg = "Error: ";
        try {
            JSONObject jObjMain = new JSONObject(s);
            msg += jObjMain.getString("message");

        } catch (JSONException e) {
            msg += e.getMessage();
        }

        String finalMsg = String.format("%s ", msg);
        Log.d(TAG, "handleError: " + finalMsg);
        //mainActivity.runOnUiThread(() -> mainActivity.handleError(finalMsg));
        // TODO: Add a handleError method in MA
    }

    public void handleResults(final String jsonString) {

        Log.d(TAG, "handleResults: " + jsonString);

        ArrayList<News> n = parseJSON(jsonString);
        if (n == null) {
            mainActivity.runOnUiThread(mainActivity::downloadFailed);
            return;
        }

        //String w = ""; //TODO: remove str w and create a Weather obj
        mainActivity.runOnUiThread(() -> mainActivity.receiveData(n));
    }


    private ArrayList<News> parseJSON(String s){

        String name;
        ArrayList<News> nList = new ArrayList<>();

        Log.d(TAG, "parseJSON: s: " + s);
        try {
            JSONObject sobj = new JSONObject(s);
            JSONArray jObjMain = sobj.getJSONArray("sources");


            InputStream isc =
                    mainActivity.getResources().openRawResource(R.raw.country_codes);
            BufferedReader ireader = new BufferedReader(new InputStreamReader(isc));

            StringBuilder result = new StringBuilder();
            for (String line; null != (line = ireader.readLine()); ) {
                result.append(line);
            }
            ArrayList<News> zodiacList = new ArrayList<>();
            JSONObject jsonCountriesCode = new JSONObject(result.toString());
            Log.d(TAG, "parseJSON: JCC: " + result.toString());
            JSONArray jcc = jsonCountriesCode.getJSONArray("countries");

            InputStream lsc =
                    mainActivity.getResources().openRawResource(R.raw.language_codes);
            BufferedReader lreader = new BufferedReader(new InputStreamReader(lsc));

            StringBuilder lresult = new StringBuilder();
            for (String line; null != (line = lreader.readLine()); ) {
                lresult.append(line);
            }
            // ArrayList<News> zodiacList = new ArrayList<>();
            JSONObject jsonLanguagesCode = new JSONObject(lresult.toString());
            Log.d(TAG, "parseJSON: JCC: " + lresult.toString());
            JSONArray lcc = jsonLanguagesCode.getJSONArray("languages");

            // JSON goodjcc = new JSONArray();
            JSONObject goodcc = new JSONObject();
            for (int i = 0; i < jcc.length(); i++){
                JSONObject tmpjobj = jcc.getJSONObject(i);

                goodcc.put(tmpjobj.getString("code"), tmpjobj.getString("name"));
                // goodjcc.put(tjo);
            }

            // JSONArray goodlcc = new JSONArray();
            JSONObject goodlc = new JSONObject();
            for (int i = 0; i < lcc.length(); i++){
                JSONObject tmpjobj = lcc.getJSONObject(i);
                // JSONObject tjo = new JSONObject();
                goodlc.put(tmpjobj.getString("code"), tmpjobj.getString("name"));
                // goodlcc.put(tjo);
            }

            Log.d(TAG, "parseJSON: Goodjcc: " + goodcc);
            Log.d(TAG, "parseJSON: Goodlcc: " + goodlc);


            for (int i = 0; i < jObjMain.length(); i++) {
                JSONObject jnewsobj = (JSONObject) jObjMain.get(i);
                // JSONObject nameObj = jnewsobj.getJSONObject("name");
                name = jnewsobj.getString("name");
                String id = jnewsobj.getString("id");
                String category = jnewsobj.getString("category");

                String cc = jnewsobj.getString("country");
                String country = goodcc.getString(cc.toUpperCase());

                String lc = jnewsobj.getString("language");
                String lang = goodlc.getString(lc.toUpperCase());

                nList.add(
                        new News(id, name, category, lang, country, lc, cc));
            }
            Collections.sort(nList);
            return nList;
        } catch (Exception e) {
            Log.d(TAG, "parseJSON: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

}
