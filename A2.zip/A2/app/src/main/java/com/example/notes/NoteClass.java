package com.example.notes;

import android.os.Build;
import android.util.JsonWriter;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

import java.io.IOException;
import java.io.Serializable;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class NoteClass implements Serializable {
    private final String title;
    private final String note;
    private final Date save_time;
    //private final String time_str;

    //DateFormat dateFormat2 = new SimpleDateFormat("dd/MM/yyyy hh.mm aa");
    //String dateString2 = dateFormat2.format(new Date()).toString();
    public NoteClass(String title, String note){
        this.title = title;
        this.note = note;

        this.save_time = new Date();

        //time_str = dt.toString();
        // save_time.toString() : gets you the str
        // save_time.parse("10-24-21 12 pm") : gets you the DateFormat
        //this.time =

    }

    public NoteClass(String title, String note, long date) {
        this.title = title;
        this.note = note;
        this.save_time = new Date(date);
    }

    public String getTitle(){return title;}
    public String getNote(){return note;}
    public Date getSave_time(){return save_time;}

    public String getTime_str(){
        SimpleDateFormat dateFormat = new SimpleDateFormat("E MMM dd, h:mm aa");
        // Good Time format!
        return dateFormat.format(save_time);
    }
    // public String getTime_str(){return save_time.toString();}
    @NonNull
    @Override
    public String toString() {
        try {
            StringWriter sw = new StringWriter();
            JsonWriter jsonWriter = new JsonWriter(sw);
            jsonWriter.setIndent("  ");
            jsonWriter.beginObject();
            jsonWriter.name("title").value(getTitle());
            jsonWriter.name("note").value(getNote());
            jsonWriter.name("save_time").value(getSave_time().getTime());
            jsonWriter.endObject();
            jsonWriter.close();
            return sw.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "";
    }
    //public
}
