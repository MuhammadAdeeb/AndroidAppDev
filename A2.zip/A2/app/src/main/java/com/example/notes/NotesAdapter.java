package com.example.notes;
//import com.example.notes.NotesVH;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Date;
import java.util.List;
import java.util.Locale;

public class NotesAdapter extends RecyclerView.Adapter<MyViewHolder>{

    private static final String TAG = "NotesAdapter";
    private final List<NoteClass> notes_list;
    private final MainActivity mainAct;

    NotesAdapter(List<NoteClass> nList, MainActivity ma) {
        this.notes_list = nList;
        mainAct = ma;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull final ViewGroup parent, int viewType) {
        Log.d(TAG, "onCreateViewHolder: MAKING NEW NotesViewHolder");

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.rv, parent, false);  //inflate using the RV layout

        itemView.setOnClickListener(mainAct);
        itemView.setOnLongClickListener(mainAct);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Log.d(TAG, "onBindViewHolder: FILLING VIEW HOLDER Note " + position);

        NoteClass note = notes_list.get(position);
        String t = note.getTitle();
        t = t.replaceAll("\n", "  ");
        if (t.length() > 38){
            holder.title_tv.setText(t.substring(0,36) + "...");
            Log.d(TAG, "onBindViewHolder: title: " + t.substring(0,33) + "...");
        }else{
            holder.title_tv.setText(t);
            Log.d(TAG, "onBindViewHolder: IN Title set Else ");
        }
        //holder.title_tv.setText(note.getTitle());  //36 chars

        String n = note.getNote();
        n = n.replaceAll("\n", "  ");  // Replace Enter w/ 2 spaces for better view
        if (n.length() > 80){
            holder.note_tv.setText(n.substring(0,80) + "...");
            Log.d(TAG, "onBindViewHolder: note: " + n.substring(0,80) + "...");
        }else{
            holder.note_tv.setText(n);
            Log.d(TAG, "onBindViewHolder: IN note set Else ");
        }
        holder.time_tv.setText(note.getTime_str());
        //holder.dateTime.setText(new Date().toString());
    }

    @Override
    public int getItemCount() {
        return notes_list.size();
    }

}
