package com.example.notes;

import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

public class MyViewHolder extends RecyclerView.ViewHolder {

    TextView title_tv;
    TextView note_tv;
    TextView time_tv;

    MyViewHolder(View view) {
        super(view);
        title_tv = view.findViewById(R.id.rv_title);
        note_tv = view.findViewById(R.id.rv_note);
        time_tv = view.findViewById(R.id.rv_time);
    }

}
