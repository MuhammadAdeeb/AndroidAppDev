package com.example.notes;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class NoteActivity extends AppCompatActivity {

    private static final String TAG = "NoteActivity";
    EditText title_tv;
    EditText note_tv;
    private ActivityResultLauncher<Intent> arl;
    boolean new_note = false;
    NoteClass note_received;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);

        title_tv = findViewById(R.id.note_title);
        note_tv = findViewById(R.id.note_note);

        // So the note is scrollable
        note_tv.setMovementMethod(new ScrollingMovementMethod());

        Intent intent = getIntent();
        if (intent.hasExtra("note")) {
            note_received = (NoteClass) intent.getSerializableExtra("note");
            if (note_received.getTitle() == "") {
                new_note = true;
                title_tv.setText("");
                note_tv.setText("");
            }else{
                title_tv.setText(note_received.getTitle());
                note_tv.setText(note_received.getNote());
            }
            //tv.setText(p.toString());
            //              HEREEEEEEEEEEEEEEEEEEEEEEEE
            //arl = registerForActivityResult(new ActivityResultLauncher.StartActivityForResult(), this::receiveNote);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_note, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.save) {
            //Implement this to save the note appropriately
            String nt = title_tv.getText().toString();
            String nn = note_tv.getText().toString();

            NoteClass n = new NoteClass(nt, nn);
            String tnt = nt.replaceAll("\\s", "");

            if (tnt.length() == 0){
                //Create Cancel/Ok Dialog
                noTitleDialog();
                /*
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setPositiveButton("OK",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        if (new_note == true){
                            // Don't save jack shiz
                            Intent intent = new Intent();
                            intent.putExtra("note", n);
                            intent.putExtra("new_note", new_note);
                            intent.putExtra("delete", "don't");
                            setResult(RESULT_OK, intent);
                            finish();
                        }else{
                            //Delete the receive Note
                            Intent intent = new Intent();
                            intent.putExtra("note", n);
                            intent.putExtra("new_note", new_note);
                            intent.putExtra("delete", "delete");
                            setResult(RESULT_OK, intent);
                            finish();
                        }

                        //Intent intent = new Intent();
                        //intent.putExtra("note", n);
                        //intent.putExtra("new_note", new_note);
                        //intent.putExtra("delete", "don't");
                        //setResult(RESULT_OK, intent);
                        //finish();

                    }


                });

                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                builder.setMessage("Note without a title will be deleted!");
                builder.setTitle("Are you Sure?");

                AlertDialog dialog = builder.create();
                dialog.show();

                */
            }else{
                Log.d(TAG, "onOptionsItemSelected: New Note to be saved is returned to MA ");
                Log.d(TAG, "onOptionsItemSelected: NOTE_TITLE: " + n.getTitle() + " NOTE_NOTE: " + n.getNote()  + " TIME: " + n.getTime_str());
                Intent intent = new Intent();
                intent.putExtra("note", n);
                intent.putExtra("new_note", new_note);
                intent.putExtra("delete", "don't");
                setResult(RESULT_OK, intent);
                finish();
                //return n;
            }
            //n.note = note_tv;
            return true;
        }else {
            return super.onOptionsItemSelected(item);
        }

    }

    @Override
    public void onBackPressed() {

        // New note or Edited note
        Log.d(TAG, "onBackPressed: TITLE: " + title_tv.getText().toString());
        if ( new_note == true || !(note_received.getTitle().equals(title_tv.getText().toString())) || !(note_received.getNote().equals(note_tv.getText().toString()))){
            //NoteClass n = new NoteClass(title_tv.getText().toString(), note_tv.getText().toString());
            //String t = n.getTitle();
            //t = t.replaceAll("//s", ""); // remove all empty spaces from the title for checking if it's empty

            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setPositiveButton("YES",new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    NoteClass n = new NoteClass(title_tv.getText().toString(), note_tv.getText().toString());
                    String t = n.getTitle();
                    t = t.replaceAll("//s", ""); // remove all empty spaces from the title for checking if it's empty
                    if (t.equals("")){
                        //Create a dialog that note w/o title will not be saved...
                        noTitleDialog();
                    }else{
                        Intent intent = new Intent();
                        intent.putExtra("note", n);
                        intent.putExtra("new_note", new_note);
                        intent.putExtra("delete", "don't");
                        setResult(RESULT_OK, intent);
                        finish();
                    }
                    /*
                    Intent intent = new Intent();
                    intent.putExtra("note", n);
                    intent.putExtra("new_note", new_note);
                    intent.putExtra("delete", "don't");
                    setResult(RESULT_OK, intent);
                    finish();
                    */
                }
            });

            builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    goBack();
                }

            });

            // builder.setMessage("Note without a title will be deleted!");
            builder.setTitle("Your Note is not Saved!\nWould you like to save this note?");
            AlertDialog dialog = builder.create();
            dialog.show();

        }else{
            goBack();
        }
        //super.onBackPressed();
    }

    public void goBack(){
        super.onBackPressed();
    }

    public void noTitleDialog(){

        String nt = title_tv.getText().toString();
        String nn = note_tv.getText().toString();

        NoteClass n = new NoteClass(nt, nn);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setPositiveButton("OK",new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

                if (new_note == true){
                    // Don't save jack shiz
                    Intent intent = new Intent();
                    intent.putExtra("note", n);
                    intent.putExtra("new_note", new_note);
                    intent.putExtra("delete", "don't");
                    setResult(RESULT_OK, intent);
                    finish();
                }else{
                    //Delete the receive Note
                    Intent intent = new Intent();
                    intent.putExtra("note", n);
                    intent.putExtra("new_note", new_note);
                    intent.putExtra("delete", "delete");
                    setResult(RESULT_OK, intent);
                    finish();
                }
                        /*
                        Intent intent = new Intent();
                        intent.putExtra("note", n);
                        intent.putExtra("new_note", new_note);
                        intent.putExtra("delete", "don't");
                        setResult(RESULT_OK, intent);
                        finish();
                         */
            }
        });

        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.setMessage("Proceed forward? ");
        builder.setTitle("Note without a title will not be saved!");

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}