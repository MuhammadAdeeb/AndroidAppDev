package com.example.notes;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity
        implements View.OnClickListener, View.OnLongClickListener{

    private static final String TAG = "MainActivity";
    private List<NoteClass> notes_lst = new ArrayList<>(); //list to store Notes
    private RecyclerView recyclerView; // Layout's recyclerview
    private NotesAdapter notes_adap; // Data to recyclerview adapter
    private ActivityResultLauncher<Intent> arl;
    private NoteClass note_received;
    private NoteClass n;
    boolean nn = false;
    private int index = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        notes_lst.addAll(loadFile());
        if (notes_lst.size() > 0){
            setTitle(String.format("%s (%d)", getString(R.string.android_notes), notes_lst.size()));
        }
        Log.d(TAG, "onCreate: " + notes_lst);

        recyclerView = findViewById(R.id.recycler);
        notes_adap = new NotesAdapter(notes_lst, this);
        recyclerView.setAdapter(notes_adap);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        arl = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), this::receiveNote);

        //registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
        //                this::handleResult);
    }

    // FOLLOWING TWO BUTTON ARE FOR OPTIONS MENU
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_res, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.info) {
            //Toast.makeText(this, "You Selected info", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, About.class);
            startActivity(intent);
            return true;
        } else if (item.getItemId() == R.id.add_note) {
            //Toast.makeText(this, "You Selected to add a note", Toast.LENGTH_SHORT).show();

            /*Things to pass in the intent
            List of Notes...SO the new note is added into the list and list is returned
            */
            // startActivity(intent);
            // DateFormat df = new SimpleDateFormat("dd/MM/yyyy hh.mm aa");
            //@RequiresApi(api = Build.VERSION_CODES.O);
            nn = true;
            Intent intent = new Intent(this, NoteActivity.class);
            n = new NoteClass("", "");
            intent.putExtra("note", n);
            arl.launch(intent);
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }
    //OPTION MENU METHODS FINISHED



    //            if (note_received.getTitle() == n.getTitle() && note_received.getNote() == note_received.getNote()){
    //                return;
    //            }
    public void receiveNote(ActivityResult result) {
        if (result == null || result.getData() == null){
            Log.d(TAG, "receiveNote: NULL Note returned");
            return;
        }
        String d;
        boolean no_edits = false;
        Intent data = result.getData();
        if(result.getResultCode() == RESULT_OK){
            note_received = (NoteClass) data.getSerializableExtra("note");
            //if
            d = data.getStringExtra("delete");
            Log.d(TAG, "receiveNote: delete val from NOTeActivity: " + d);
            if(!d.equals("delete")){
                if (nn == true){
                    if (!(note_received.getTitle().equals(""))){
                        notes_lst.add(0, note_received);
                        notes_adap.notifyItemInserted(0);
                        Log.d(TAG, "receiveNote: **NEW NOTE**: Right b4 saveNote is called ");
                        saveNote();
                        if (notes_lst.size() > 0){
                            setTitle(String.format("%s (%d)", getString(R.string.android_notes), notes_lst.size()));
                        }

                    }else{
                        Log.d(TAG, "receiveNote: 1st else!");
                        Toast.makeText(this, "Note without Title wasn't saved! ", Toast.LENGTH_LONG).show();
                        return;} // empty new note returned
                } else{
                    Log.d(TAG, "receiveNote: inside 2nd else!");
                    try {
                        Log.d(TAG, "receiveNote: n printed: " + n.getTitle() + " " + n.getNote());
                        Log.d(TAG, "receiveNote: " + note_received.getTitle() + "   " + note_received.getNote());

                        if (!note_received.getTitle().equals(n.getTitle()) || !note_received.getNote().equals(n.getNote())){
                            Log.d(TAG, "In THE IF STATEMENT!!!!!!");

                            Log.d(TAG, "receiveNote: Note has been edited");
                            //edits have been made
                            NoteClass temp_n = new NoteClass(note_received.getTitle(), note_received.getNote());
                            notes_lst.remove(this.index);
                            notes_lst.add(0, temp_n);

                            Log.d(TAG, "receiveNote: UPDATED LIST: " + notes_lst);

                            //notes_adap.notifyAll();
                            Log.d(TAG, "receiveNote: Right b4 Adapter is updated");
                            notes_adap.notifyDataSetChanged();
                            Log.d(TAG, "receiveNote: Right b4 saveNote is called!");
                            saveNote();
                        }
                    } catch (Exception e) {
                        Log.d(TAG, "Object: " + note_received);
                    }
                }
            }else{
                //whatever note has been returned needs to be deleted
                //notes_lst.remove(index);
                // notes_adap.notifyItemRemoved(index);
                Toast.makeText(this, "There must be a title to save Note Edits! ", Toast.LENGTH_LONG).show();

                saveNote();
            }
        }

        //Update the count of the app title
        if (notes_lst.size() > 0){
            setTitle(String.format("%s (%d)", getString(R.string.android_notes), notes_lst.size()));
        }else{
            setTitle(String.format("%s", getString(R.string.android_notes)));
        }

    }


    // FOLLOWING TWO METHODS ARE FOR ONCLICKLISTENERS
    @Override
    public void onClick(View v) {  // click listener called by ViewHolder clicks
        //int pos = recyclerView.getChildLayoutPosition(v);
        //Employee m = employeeList.get(pos);
        //Toast.makeText(v.getContext(), "SHORT " + m.toString(), Toast.LENGTH_SHORT).show();
        nn = false;
        Intent intent = new Intent(this, NoteActivity.class);

        int pos = recyclerView.getChildLayoutPosition(v);
        n = notes_lst.get(pos);
        this.index = pos;

        // n = new NoteClass("", "");
        intent.putExtra("note", n);
        arl.launch(intent);
        // return true;
    }

    // From OnLongClickListener
    @Override
    public boolean onLongClick(View v) {  // long click listener called by ViewHolder long clicks
        //int pos = recyclerView.getChildLayoutPosition(v);
        //Employee m = employeeList.get(pos);
        //Toast.makeText(v.getContext(), "LONG " + m.toString(), Toast.LENGTH_SHORT).show();
        int pos = recyclerView.getChildLayoutPosition(v);
        NoteClass del_n = notes_lst.get(pos);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setPositiveButton("YES",new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {
                notes_lst.remove(pos);
                notes_adap.notifyItemRemoved(pos);
                if (notes_lst.size() > 0){
                    setTitle(String.format("%s (%d)", getString(R.string.android_notes), notes_lst.size()));
                }else{
                    setTitle(getString(R.string.android_notes));
                }

                saveNote();
            }
            /*
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
            */
        });

        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
            /*
            public void onClick(DialogInterface dialog, int which) {
                notes_lst.remove(pos);
                notes_adap.notifyItemRemoved(pos);
                if (notes_lst.size() > 0){
                    setTitle(String.format("%s (%d)", getString(R.string.android_notes), notes_lst.size()));
                }else{
                    setTitle(getString(R.string.android_notes));
                }

                saveNote();
            }
            */

        });
        // -> tv5.setText(getString(R.string.cxl_selected)));

        builder.setMessage("");

        builder.setTitle("Delete Note '" + del_n.getTitle() + "'?");

        AlertDialog dialog = builder.create();
        dialog.show();



        return false;
    }
    // ONCLICKLISTENERS METHODS FINISHED

    // IF BACK BUTTON IS PRESSED
    //      DO: 2 options
    //          i) If new: save or not dialog
    //          ii) If old & unedited: exit & return to MA
    @Override
    public void onBackPressed() {
        //Toast.makeText(this, "The back button was pressed - Bye!", Toast.LENGTH_SHORT).show();
        super.onBackPressed();
    }

    private ArrayList<NoteClass> loadFile() {

        Log.d(TAG, "loadFile: Loading JSON File");
        ArrayList<NoteClass> noteList = new ArrayList<>();
        try {
            InputStream is = getApplicationContext().openFileInput(getString(R.string.file_name));
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));

            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }

            Log.d(TAG, "loadFile: b4 JSON Arr dec");
            Log.d(TAG, "loadFile: " + sb.toString());
            JSONArray jsonArray = new JSONArray(sb.toString());  //Puts the String Builder content in the JSONArray!!!
            Log.d(TAG, "loadFile: right b4 for loop");
            for (int i = 0; i < jsonArray.length(); i++) {
                Log.d(TAG, "loadFile: inside for loop");
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String title = jsonObject.getString("title");
                String nt = jsonObject.getString("note");
                long date = jsonObject.getLong("save_time");
                Log.d(TAG, jsonObject.toString());
                Log.d(TAG, "loadFile: title: " + title + " note: " + nt);
                Log.d(TAG, "loadFile: in for loop, right b4 the note is created: " + i );


                NoteClass note = new NoteClass(title, nt, date); // TODO: Gotta convert Str date to Dateformat
                Log.d(TAG, "loadFile: NOTE: " + note);
                noteList.add(note);
            }

        } catch (FileNotFoundException e) {
            // Toast.makeText(this, getString(R.string.no_file), Toast.LENGTH_SHORT).show(); //This is
            Log.d(TAG, "loadFile: No file Found");
        } catch (Exception e) {
            // notes_lst.clear();
            // saveNote();
            Log.d(TAG, "loadFile: EXCEPTION e");
            e.printStackTrace();
        }
        return noteList;
    }

    private void saveNote() {

        Log.d(TAG, "saveProduct: Saving JSON File");

        try {
            FileOutputStream fos = getApplicationContext().
                    openFileOutput(getString(R.string.file_name), Context.MODE_PRIVATE);

            PrintWriter printWriter = new PrintWriter(fos);
            printWriter.print(notes_lst);
            printWriter.close();
            fos.close();

            Log.d(TAG, "saveProduct: JSON:\n" + notes_lst.toString());

            //Toast.makeText(this, getString(R.string.saved), Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.getStackTrace();
        }
    }
}